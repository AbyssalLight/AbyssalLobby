#Overview
This is a mod planned to add improvments to your modded experiance.

#Curently Implemented Features
-Scrolable Lobby 
	(via ScrollableLobbyUI)
-Item and equipment vote system
-In lobby item and equipment descriptions

#Future Plans
-Many aesthetic changes
-Suggestions or comments, feel free to ping me in the RoR2 Modding Discord or just DM me : AbyssalLight#1688

#Updates
```
2.2.1 - Color improvments
2.2.0 - Added Item and Equipment Descriptions in lobby
2.1.0 - Fixed RuleBook.GetRuleChoice error
2.0.0 - Re-release as AbyssalLobby
1.0.1 - Equipment reorder
1.0.0 - Release on Thunderstore as AbyssalItemVotes
```