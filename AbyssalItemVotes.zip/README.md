#Overview
This mod allows you and your friends to enable a disable items for your runs. With the vast amounts of Items that modds add, there getts to be too many to handle. 

#Thanks
This mod is based off a mod by RyanP but as he has decided to no longer update it, I have taken it upon myself to improve this mod as best I can.

#Contact
Suggestions or comments, feel free to ping me in the RoR2 Modding Discord or just DM me : AbyssalLight#1688

#Future Plans
-Many aesthetic changes
-better scrolling
-...

#Updates
```
1.0.1 - equipment reorder
1.0.0 - Release on Thunderstore
```